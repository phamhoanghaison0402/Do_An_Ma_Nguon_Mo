<?php
// Position
$_['heading_title'] = ' <span style="color:#E1653B"> Pav Blog Dernières Commentaire Module </ span >';

// Texte
$_['text_module'] = ' modules' ;
$_['text_success'] = ' Succès : Vous avez modifié module Diaporama ';
$_['text_content_top'] = 'Contenu Top' ;
$_['text_content_bottom'] = ' Bottom de contenu ' ;
$_['text_column_left'] = ' la colonne de gauche ' ;
$_['text_column_right'] = ' Colonne de droite ';
$_['text_mainmenu'] = ' Menu ';
$_['text_slideshow'] = ' Diaporama ';
$_['text_promotion'] = ' Promotion' ;
$_['text_bottom1'] = ' Bottom 1';
$_['text_bottom2'] = ' Bottom 2' ;
$_['text_bottom3'] = ' Bottom 3';
$_['text_footer_top'] = ' Footer Top' ;
$_['text_footer_center'] = ' Centre footer' ;
$_['text_footer_bottom'] = ' Bottom footer' ;
$_['all_page'] = ' Toutes page' ;
// Entrée
$_['entry_banner'] = ' Bannière :';
$_['entry_dimension'] = ' Dimension (L x H) et Redimensionner Type: ';
$_['entry_layout'] = 'Mise en page :';
$_['entry_position'] = 'Position :';
$_['entry_status'] = 'Status :';
$_['entry_sort_order'] = ' Ordre de tri :';
$_['entry_carousel'] = ' Limite Articles :';
$_['Entry_tabs'] = ' produit Type Tab' ;
$_['Entry_description'] = 'Description du module ';


$_['text_latest'] = 'latest' ;
$_['text_mostviewed'] = ' Les plus populaires' ;
$_['text_featured'] = ' Sélection ';
$_['text_bestseller'] = ' best-seller ';
$_['text_special'] = 'Special' ;
$_['button_blog_management'] = ' Gestion Blog ';
// Error
$_['error_permission'] = ' Attention: Vous n\'avez pas la permission de modifier le module diaporama ';
$_['error_dimension'] = ' largeur et hauteur dimensions requises ! ' ;
$_['error_carousel'] = 'width & Max Objets - Colonnes de Max - limiter les éléments requis dans le carrousel ! ' ;

?>
