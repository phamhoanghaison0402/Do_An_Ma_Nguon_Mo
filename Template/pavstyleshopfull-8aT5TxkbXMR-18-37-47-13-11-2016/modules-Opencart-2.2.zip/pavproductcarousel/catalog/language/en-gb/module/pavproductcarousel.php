<?php
// Heading 
$_['heading_title'] = 'Latest';

// Text
$_['text_latest']  = 'Latest'; 
$_['text_mostviewed']  = 'Most Viewed'; 
$_['text_featured']  = 'Featured'; 
$_['text_bestseller']  = 'Best Seller'; 
$_['text_special']  = 'Special';
$_['text_toprating']  = 'Top Rating'; 

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Save: %s';

$_['quick_view'] = 'Quick View';

$_['text_featured_oneshop']  = 'Featured Product';
$_['button_compare']        = 'Add to Compare';
$_['button_wishlist']       = 'Add to Wish List';
?>
