<?php  

$_['hot'] = "hot";
$_['sale'] = "sale";
$_['new'] = "new";

?>