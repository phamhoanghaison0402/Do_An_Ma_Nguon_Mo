<?php
/******************************************************
 * @package Pav Product Tabs module for Opencart 1.5.x
 * @version 1.0
 * @author http://www.pavothemes.com
 * @copyright	Copyright (C) Feb 2012 PavoThemes.com <@emai:pavothemes@gmail.com>.All rights reserved.
 * @license		GNU General Public License version 2
*******************************************************/
// Heading 
$_['heading_title'] = 'Sản phẩm mới nhất';

// Text
$_['text_latest']  = 'Mới nhất'; 
$_['text_mostviewed']  = 'Xem nhiều nhất'; 
$_['text_featured']  = 'Nổi bật'; 
$_['text_bestseller']  = 'Bán chạy'; 
$_['text_special']  = 'Đặc biệt';

$_['text_sale'] = 'Sale';
$_['text_sale_detail'] = 'Lưu: %s';
$_['quick_view'] = 'Xem nhanh';
?>