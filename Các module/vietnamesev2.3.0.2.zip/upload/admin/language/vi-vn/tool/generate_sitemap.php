<?php
// ------------------------------------------------
// Generate Google Site Maps for OpenCart v1.5.1.x
// By Best-Byte
// www.best-byte.com
// ------------------------------------------------
?>
<?php
// Heading
$_['heading_title']    = 'Generate Site Maps';

// Text
$_['button_generate']  = 'Generate';
$_['text_success']     = 'Success: You have successfully generated site maps!';
$_['text_failure']     = 'Error: Please try again!';
$_['text_common']      = 'Click the Generate button to generate site maps. The site maps will be created in the sitemaps folder.';
?>