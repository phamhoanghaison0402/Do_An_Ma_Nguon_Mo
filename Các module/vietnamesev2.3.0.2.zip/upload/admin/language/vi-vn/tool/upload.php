<?php
// Heading
$_['heading_title']     = 'Tải lên';

// Text
$_['text_success']      = 'Hoàn tất: Bạn đã sửa đổi mục tải lên!';
$_['text_list']         = 'Danh sách đã tải lên';

// Column
$_['column_name']       = 'Tiêu đề';
$_['column_filename']   = 'Tên tệp';
$_['column_date_added'] = 'Ngày thêm';
$_['column_action']     = 'Thao tác';

// Entry
$_['entry_name']        = 'Tiêu đề';
$_['entry_filename']    = 'Tên tệp';
$_['entry_date_added'] 	= 'Ngày thêm';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không đủ quyền hạn thực hiện thao tác này!';