<?php
// Heading
$_['heading_title']      = 'NOCHEX';

// Text 
$_['text_payment']       = 'Thanh Toán';
$_['text_success']       = 'Thành Công: Bạn đã thay đổi chi tiết tài khoản NOCHEX!';
$_['text_edit']                     = 'Edit NOCHEX';
$_['text_nochex']	     = '<a onclick="window.open(\'https://secure.nochex.com/apply/merchant_info.aspx?partner_id=172198798\');"><img src="view/image/payment/nochex.png" alt="NOCHEX" title="NOCHEX" style="border: 1px solid #EEEEEE;" /><br /></a>';
$_['text_seller']        = 'Tài khoản cá nhân / người bán';
$_['text_merchant']      = 'Merchant Account';
      
// Entry
$_['entry_email']        = 'E-Mail:';
$_['entry_account']      = 'Loại tài khoản:';
$_['entry_merchant']     = 'Merchant ID:';
$_['entry_template']     = 'Pass Template:';
$_['entry_test']         = 'Kiểm tra:';
$_['entry_total']        = 'Tổng cộng:<br /><span class="help">Kiểm tra tất cả các đơn hàng trước khi thanh toán được kích hoạt.</span>';
$_['entry_order_status'] = 'Trạng thái đơn hàng:';
$_['entry_geo_zone']     = 'Vùng tính thuế';
$_['entry_status']       = 'Trạng thái:';
$_['entry_sort_order']   = 'Sắp xếp đơn hàng:';

// Help
$_['help_total']					= 'The checkout total the order must reach before this payment method becomes active.';
// Error
$_['error_permission']   = 'Cảnh báo:Bạn không có quyền sửa đổi thanh toán NOCHEX!';
$_['error_email']        = 'Yêu cầu E-Mail!';
$_['error_merchant']     = 'Yêu cầu Merchant ID!';
?>