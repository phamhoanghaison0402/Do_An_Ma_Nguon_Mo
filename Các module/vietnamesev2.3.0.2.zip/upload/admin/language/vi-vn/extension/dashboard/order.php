<?php
// Heading
$_['heading_title'] = 'Tổng thể về đơn hàng';

// Text
$_['text_view']     = 'Xem chi tiết...';