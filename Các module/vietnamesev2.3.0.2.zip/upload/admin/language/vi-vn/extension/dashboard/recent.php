<?php
// Heading
$_['heading_title']     = 'Các đơn hàng gần đây';

// Column
$_['column_order_id']   = 'Số ID đơn hàng';
$_['column_customer']   = 'Khách hàng';
$_['column_status']     = 'Trạng thái';
$_['column_total']      = 'Tổng số';
$_['column_date_added'] = 'Ngày được đặt';
$_['column_action']     = 'Thao tác';