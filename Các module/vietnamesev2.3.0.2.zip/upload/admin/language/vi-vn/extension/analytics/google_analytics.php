<?php
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_extension']   = 'Phần mở rộng';
$_['text_success']	   = 'Hoàn tất: Bạn đã sửa đổi Analytics!';
$_['text_signup']      = 'Đăng nhập vào tài khoản<a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> tạo hồ sơ trang web của bạn và sao chép mã analytics vào mục này.';
$_['text_default']     = 'Mặc định';

// Entry
$_['entry_code']       = 'Mã Google Analytics';
$_['entry_status']     = 'Trạng thái';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không đủ quyền hạn thực hiện thao tác này!';
$_['error_code']	   = 'Bạn phải nhập mã!';
