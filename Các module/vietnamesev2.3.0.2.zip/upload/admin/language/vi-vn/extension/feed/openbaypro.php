<?php
// Heading
$_['heading_title']	  = 'OpenBay Pro';

// Text
$_['text_module']    = 'Các mô đun';
$_['text_installed'] = 'Mô đun OpenBay Pro chưa được cài đặt. Hãy cài đặt từ: Phần mở rộng -> OpenBay Pro';