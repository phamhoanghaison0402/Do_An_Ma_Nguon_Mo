<?php
// Heading
$_['heading_title']    = 'Google Sitemap';

// Text
$_['text_feed']        = 'Feeds';
$_['text_success']     = 'Hoàn tất: Bạn đã thay đổi Google Sitemap feed!';
$_['text_edit']        = 'Sửa Google Sitemap';

// Entry
$_['entry_status']     = 'Trạng thái';
$_['entry_data_feed']  = 'Liên kết dữ liệu Feed';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không đủ quyền hạn để sửa Google Sitemap feed!';