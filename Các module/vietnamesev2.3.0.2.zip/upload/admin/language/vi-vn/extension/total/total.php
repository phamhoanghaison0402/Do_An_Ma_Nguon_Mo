<?php
// Heading
$_['heading_title']    = 'Tổng số tiền thanh toán';

// Text
$_['text_total']       = 'Tổng số đơn đặt hàng';
$_['text_success']     = 'Thành công: bạn đã thay đổi tổng số!';
$_['text_edit']        = 'Chỉnh sửa Tổng số Total';

// Entry
$_['entry_status']     = 'Tình trạng:';
$_['entry_sort_order'] = 'Thứ tự:';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không có quyền sửa đổi tổng số!';
?>