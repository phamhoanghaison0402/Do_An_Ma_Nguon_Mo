<?php
$_['lang_openbay_new']              = 'Create new listing';
$_['lang_openbay_edit']             = 'View / Edit listing';
$_['lang_openbay_fix']              = 'Fix errors';
$_['lang_openbay_processing']       = 'Processing';

$_['lang_amazonus_saved']           = 'Saved (not uploaded)';
$_['lang_amazon_saved']             = 'Saved (not uploaded)';
$_['lang_play_pending_new']         = 'Pending (new)';
$_['lang_play_pending_updated']     = 'Pending (updated)';
$_['lang_play_warning']             = 'Warning messages';
$_['lang_play_pending_delete']      = 'Pending delete';
$_['lang_play_stock_updating']      = 'Stock updating';

$_['lang_markets']                  = 'Markets';
$_['lang_bulk_btn']                 = 'eBay bulk upload';

$_['lang_marketplace']              = 'Marketplace';
$_['lang_status']                   = 'Trạng thái';
$_['lang_option']                   = 'Tùy chọn';