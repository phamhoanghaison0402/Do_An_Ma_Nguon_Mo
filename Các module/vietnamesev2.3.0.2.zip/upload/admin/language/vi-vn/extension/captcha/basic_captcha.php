<?php
$_['heading_title']    = 'Captcha cơ bản';

// Text
$_['text_captcha']     = 'Captcha';
$_['text_success']	   = 'Hoàn tất: Bạn đã sửa đổi Captcha cơ bản!';
$_['text_edit']        = 'Sửa Captcha cơ bản';

// Entry
$_['entry_status']     = 'Trạng thái';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không đủ quyền hạn thực hiện thao tác này!';
