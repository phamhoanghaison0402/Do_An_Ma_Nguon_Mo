<?php
// Heading
$_['heading_title']  = 'Các phần mở rộng';

// Text
$_['text_success']   = 'Hoàn tất: Bạn đã sửa đổi các phần mở rộng!';
$_['text_list']      = 'Danh sách các phần mở rộng';
$_['text_type']      = 'Chọn thể loại';
$_['text_filter']    = 'Lọc';
$_['text_analytics'] = 'Analytics';
$_['text_captcha']   = 'Captcha';
$_['text_dashboard'] = 'Bảng điều khiển';
$_['text_feed']      = 'Feeds';
$_['text_fraud']     = 'Chống gian lận';
$_['text_module']    = 'Các Module';
$_['text_content']   = 'Module về nội dung';
$_['text_menu']      = 'Module về Menu';
$_['text_payment']   = 'Cổng thanh toán';
$_['text_shipping']  = 'Vận chuyển';
$_['text_theme']     = 'Mẫu gian hàng';
$_['text_total']     = 'Tổng đơn hàng';