<?php
// Heading
$_['heading_title']     = 'Bảng điều khiển';

// Text
$_['text_success']      = 'Hoàn tất: Bạn đã sửa đổi bảng điều khiển!';
$_['text_list']         = 'Danh sách';

// Column
$_['column_name']       = 'Tên';
$_['column_width']      = 'Rộng';
$_['column_status']     = 'Trạng thái';
$_['column_sort_order'] = 'Thứ tự';
$_['column_action']     = 'Thao tác';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không đủ quyền hạn thực hiện thao tác này!';