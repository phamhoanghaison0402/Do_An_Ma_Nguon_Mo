<?php
// Heading
$_['heading_title']    = 'Các mẫu gian hàng';

// Text
$_['text_success']     = 'Hoàn tất: Bạn đã sửa đổi các mẫu gian hàng!';
$_['text_list']        = 'Danh sách các mẫu';

// Column
$_['column_name']      = 'Tên mẫu';
$_['column_status']    = 'Trạng thái';
$_['column_action']    = 'Thao tác';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không đủ quyền hạn thực hiện thao tác này!';