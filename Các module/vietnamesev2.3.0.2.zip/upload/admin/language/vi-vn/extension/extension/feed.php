<?php
// Heading
$_['heading_title']      = 'Feeds sản phẩm';

// Text
$_['text_success']     = 'Hoàn tất: Bạn đã thay đổi feeds cho sản phẩm!';
$_['text_install']       = 'Cài đặt';
$_['text_list']        = 'Danh sách feed';
$_['text_uninstall']     = 'Gỡ bỏ';

// Column
$_['column_name']        = 'Tên nguồn cấp';
$_['column_status']      = 'Trạng thái';
$_['column_action']      = 'Thao tác';

// Error
$_['error_permission']  = 'Cảnh báo: Bạn không có quyền sửa đổi nguồn cung cấp!';
?>