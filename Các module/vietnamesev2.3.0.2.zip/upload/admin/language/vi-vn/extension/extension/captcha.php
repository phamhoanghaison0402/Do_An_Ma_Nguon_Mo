<?php
// Heading
$_['heading_title']    = 'Captcha';

// Text
$_['text_success']     = 'Hoàn tất: Bạn đã sửa đổi captchas!';
$_['text_list']        = 'Danh sách các Captcha';

// Column
$_['column_name']      = 'Tên Captcha';
$_['column_status']    = 'Trạng thái';
$_['column_action']    = 'Thao tác';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không đủ quyền hạn thực hiện thao tác này!';
