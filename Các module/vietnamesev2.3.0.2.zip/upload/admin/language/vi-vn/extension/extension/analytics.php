<?php
// Heading
$_['heading_title']    = 'Analytics';

// Text
$_['text_success']     = 'Hoàn tất: Bạn đã sửa đổi Analytics!';
$_['text_list']        = 'Danh sách Analytics';

// Column
$_['column_name']      = 'Tên Analytics';
$_['column_status']    = 'Trạng thái';
$_['column_action']    = 'Thao tác';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không đủ quyền hạn thực hiện thao tác này!';
