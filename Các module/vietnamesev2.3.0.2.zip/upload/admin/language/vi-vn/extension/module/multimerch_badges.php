<?php

$_['heading_title']    = '<b>[MultiMerch]</b> Seller Badges';
$_['text_module']         = 'Modules';

$_['ms_menu_badge'] = 'Badges';

$_['ms_config_badge_size'] = 'Badge size';

// Badges
$_['ms_catalog_badges_breadcrumbs'] = 'Badges';
$_['ms_catalog_badges_heading'] = 'Badges';
$_['ms_catalog_badges_image'] = 'Image';
$_['ms_badges_column_id'] = 'ID';
$_['ms_badges_column_name'] = 'Name';
$_['ms_badges_image'] = 'Image';
$_['ms_badges_column_action'] = 'Action';
$_['ms_catalog_insert_badge_heading'] = 'Create badge';
$_['ms_catalog_edit_badge_heading'] = 'Edit badge';
$_['ms_success_badge_created'] = 'Badge created';
$_['ms_success_badge_updated'] = 'Badge updated';
$_['ms_error_badge_name'] = 'Please specify a name for the badge';

?>