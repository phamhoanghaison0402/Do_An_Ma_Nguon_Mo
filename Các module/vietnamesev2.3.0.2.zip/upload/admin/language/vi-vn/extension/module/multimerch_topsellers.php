<?php

$_['heading_title']    = '[MultiMerch] Top Sellers Module Addon';
$_['text_module']         = 'Modules';

$_['ms_config_topsellers'] = 'Top sellers';

?>
