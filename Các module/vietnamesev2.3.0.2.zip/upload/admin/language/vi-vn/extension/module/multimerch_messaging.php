<?php

$_['heading_title']    = '<b>[MultiMerch]</b> Private Messaging System';
$_['text_module']         = 'Modules';

$_['mmes_messaging'] = 'Private Messaging';

$_['mmess_config_enable'] = 'Enable private messaging for MultiMerch';

?>