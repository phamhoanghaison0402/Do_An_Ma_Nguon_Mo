<?php

$_['heading_title']    = '[MultiMerch] New Sellers Module Addon';
$_['text_module']         = 'Modules';

$_['ms_config_newsellers'] = 'New sellers';

?>