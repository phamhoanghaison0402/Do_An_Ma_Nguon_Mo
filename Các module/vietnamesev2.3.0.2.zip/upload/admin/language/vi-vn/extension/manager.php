<?php
// Heading 
$_['heading_title']    = 'Qu?n l� ph?n m? r?ng';

// Text
$_['text_success']     = 'Ho�n t?t: B?n d� c�i d?t xong ph?n m? r?ng!';

// Error
$_['error_permission'] = 'C?nh b�o: B?n kh�ng d? quy?n h?n th?c hi?n thao t�c n�y!';
$_['error_upload']     = 'Y�u c?u ch?n t?p t?i l�n!';
$_['error_filetype']   = '�?nh d?ng t?p kh�ng du?c h? tr?!';
