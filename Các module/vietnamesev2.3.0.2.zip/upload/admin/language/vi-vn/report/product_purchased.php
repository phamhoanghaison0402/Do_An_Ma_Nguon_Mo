<?php
// Heading
$_['heading_title']     = 'Báo cóa mua sản phẩm';

// Text
$_['text_list']         = 'Products Purchased List';
$_['text_all_status']   = 'Tất cả các trạng thái';

// Column
$_['column_date_start'] = 'Ngày bắt đầu';
$_['column_date_end']   = 'Ngày kết thúc';
$_['column_name']       = 'Tên sản phẩm';
$_['column_model']      = 'Model';
$_['column_quantity']   = 'Số lượng';
$_['column_total']      = 'Tổng cộng';

// Entry
$_['entry_date_start']  = 'Ngày bắt đầu:';
$_['entry_date_end']    = 'Ngày kết thúc:';
$_['entry_status']      = 'Trạng thái đơn hàng:';
?>