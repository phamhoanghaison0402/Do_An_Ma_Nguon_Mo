<?php
// Heading
$_['heading_title']  = 'Báo cáo sản phẩm được xem';

// Text
$_['text_list']        = 'Products Viewed List';
$_['text_success']   = 'Thành Công: Bạn đã thiết lập lại các báo cáo sản phẩm được xem!';
$_['text_success']     = 'Success: You have reset the product viewed report!';

// Column
$_['column_name']    = 'Tên sản phẩm';
$_['column_model']   = 'Model';
$_['column_viewed']  = 'Đã xem';
$_['column_percent'] = 'phần trăm';

// Error
$_['error_permission'] = 'Warning: You do not have permission to reset product viewed report!';
?>