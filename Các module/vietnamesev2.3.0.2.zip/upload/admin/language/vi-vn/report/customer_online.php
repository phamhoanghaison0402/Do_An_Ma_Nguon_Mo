<?php

// Heading

$_['heading_title']     = 'Báo cáo khách trực tuyến';



// Text 

$_['text_list']         = 'Danh sách khách trực tuyến';

$_['text_guest']        = 'Khách';

 

// Column

$_['column_ip']         = 'IP';

$_['column_customer']   = 'Khách';

$_['column_url']        = 'Trực tuyến lần cuối';

$_['column_referer']    = 'Nơi truy cập';

$_['column_date_added'] = 'Lần cuối truy cập';

$_['column_action']     = 'Thao tác';

// Entry

$_['entry_ip']          = 'IP';

$_['entry_customer']    = 'Khách';





