<?php
// Heading
$_['heading_title']     = 'Báo cáo tiền hoa hồng cho các đại lý liên kết';

// Text
$_['text_list']         = 'Danh sách ';

// Column
$_['column_affiliate']  = 'Tên liên kết ĐL';
$_['column_email']      = 'E-Mail';
$_['column_status']     = 'Trạng thái';
$_['column_commission'] = 'Hoa hồng';
$_['column_orders']     = 'Số. Đơn hàng';
$_['column_total']      = 'Tổng';
$_['column_action']     = 'Thao tác';

// Entry
$_['entry_date_start']  = 'Từ ngày';
$_['entry_date_end']    = 'Đến ngày';