<?php
// Text
$_['text_footer'] = '';
$_['text_version'] 	= 'Phiên bản %s';
