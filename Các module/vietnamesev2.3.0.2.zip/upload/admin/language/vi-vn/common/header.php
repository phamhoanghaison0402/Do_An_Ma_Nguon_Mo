<?php
// Heading
$_['heading_title']          = 'OpenCart';

// Text
$_['text_order']             = 'Các đơn hàng';
$_['text_processing_status'] = 'Đang xử lý';
$_['text_complete_status']   = 'Đã hoàn tất';
$_['text_customer']          = 'Khách hàng';
$_['text_online']            = 'Khách online';
$_['text_approval']          = 'Chờ duyệt';
$_['text_product']           = 'Sản phẩm';
$_['text_stock']             = 'Hết hàng';
$_['text_review']            = 'Đánh giá';
$_['text_return']            = 'Hàng trả lại';
$_['text_affiliate']         = 'Affiliates';
$_['text_store']             = 'Gian hàng';
$_['text_front']             = 'Cửa hàng';
$_['text_help']              = 'Hỗ trợ';
$_['text_homepage']          = 'Trang chủ OpenCart';
$_['text_support']           = 'Diễn đàn';
$_['text_documentation']     = 'Tài liệu';
$_['text_logout']            = 'Thoát';
