<?php
$_['text_complete_status']   = 'Đơn hàng được hoàn tất'; 
$_['text_processing_status'] = 'Đang sử lý đơn hàng'; 
$_['text_other_status']      = 'Trạng thái khác'; 