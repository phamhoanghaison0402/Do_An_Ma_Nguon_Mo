<?php
$_['heading_title']    = 'Google Analytics';

// Text
$_['text_analytics']   = 'Analytics';
$_['text_success']	   = 'Hoàn tất: Bạn đã sửa đổi Google Analytics!';
$_['text_edit']        = 'Sửa Google Analytics';
$_['text_signup']      = 'Đăng nhập vào tài khoản <a href="http://www.google.com/analytics/" target="_blank"><u>Google Analytics</u></a> của bạn, tạo hồ sơ sau đó sao chép analytics code và dán vào đây.';

// Entry
$_['entry_code']       = 'Google Analytics Code';
$_['entry_status']     = 'Trạng thái';

// Error
$_['error_permission'] = 'Cảnh báo: Bạn không đủ quyền hạn để sửa đổi Google Analytics!';
$_['error_code']	   = 'Bạn phải điền code!';
