HOW TO INSTALL/USE
------------------

Full install/use documentation :  http://www.oc-extensions.com/Facebook-Comments-Opencart-2.x    (see Help Tab)
 